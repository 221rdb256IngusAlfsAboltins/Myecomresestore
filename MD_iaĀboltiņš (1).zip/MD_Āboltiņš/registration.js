const registrationForm = document.getElementById("registrationForm");
registrationForm.addEventListener("submit", (event) => {
  console.log(" ir okr");
  const errorMessages = {
    firstName: "Vārdā nedrīkst būt cipari.",
    lastName: "Uzvārdā nedrīkst būt cipari.",
    email: "Lūdzu, ievadiet derīgu e-pasta adresi.",
    phone: "Telefona numuram jāsatur tikai cipari.",
    password: "Parolei jābūt vismaz 6 rakstzīmēm garai.",
    confirmPassword: "Paroles nesakrīt.",
    privacyPolicy: "Lai turpinātu, piekrītiet privātuma politikai.",
    termsAndConditions: "Lai turpinātu, piekrītiet noteikumiem.",
  };
  event.preventDefault(); 

 
  clearErrorMessages();

 
  let isValid = true;

  Object.keys(errorMessages).forEach((fieldName) => {
    const fieldValue = registrationForm.elements[fieldName].value.trim();
    const errorMessageId = `${fieldName}Error`;
    const errorMessageElement = document.getElementById(errorMessageId);

    if (fieldName === "email" && !isValidEmail(fieldValue)) {
      isValid = false;
      errorMessageElement.textContent = errorMessages[fieldName];
    } else if (fieldName === "phone" && !isValidPhoneNumber(fieldValue)) {
      isValid = false;
      errorMessageElement.textContent = errorMessages[fieldName];
    } else if (
      (fieldName === "firstName" || fieldName === "lastName") &&
      !isValidName(fieldValue)
    ) {
      isValid = false;
      errorMessageElement.textContent = errorMessages[fieldName];
    } else if (
      fieldName === "confirmPassword" &&
      fieldValue !== registrationForm.elements["password"].value
    ) {
      isValid = false;
      errorMessageElement.textContent = errorMessages[fieldName];
    } else if (
      (fieldName === "privacyPolicy" || fieldName === "termsAndConditions") &&
      !registrationForm.elements[fieldName].checked
    ) {
      isValid = false;
      errorMessageElement.textContent = errorMessages[fieldName];
    } else if (fieldName === "password" && fieldValue.length < 6) {
      isValid = false;
      errorMessageElement.textContent = errorMessages[fieldName];
    }
  });

  if (isValid) {
   
    registrationForm.submit();
  } else {
    
    const globalErrorMessage = document.getElementById("globalErrorMessage");
    globalErrorMessage.textContent =
      "Lūdzu, aizpildiet obligātos laukus pareizi.";
  }
});

function clearErrorMessages() {
    const allErrorMessages = document.querySelectorAll('.error-message');
    allErrorMessages.forEach(message => {
        message.textContent = '';
    });
    document.getElementById('globalErrorMessage').textContent = '';
}


function isValidEmail(email) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}


function isValidPhoneNumber(phone) {
    const phonePattern = /^\d+$/;
    return phonePattern.test(phone);
}


function isValidName(name) {
    const namePattern = /^[^\d]+$/;
    return namePattern.test(name);
}
