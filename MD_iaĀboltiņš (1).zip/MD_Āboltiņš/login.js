const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", (event) => {
  console.log("nav labi");
  const errorMessages = {
    email: "Lūdzu, ievadiet derīgu e-pasta adresi.",
    password: "Parolei jābūt vismaz 6 rakstzīmēm garai.",
  };
  event.preventDefault();

 
  clearErrorMessages();

  let isValid = true;

  Object.keys(errorMessages).forEach((fieldName) => {
    const fieldValue = loginForm.elements[fieldName].value.trim();
    const errorMessageId = `${fieldName}Error`;
    const errorMessageElement = document.getElementById(errorMessageId);

    if (fieldName === "email" && !isValidEmail(fieldValue)) {
      isValid = false;
      errorMessageElement.textContent = errorMessages[fieldName];
    } else if (fieldName === "password" && fieldValue.length < 6) {
      isValid = false;
      errorMessageElement.textContent = errorMessages[fieldName];
    }
  });

  if (isValid) {

    loginForm.submit();
  } else {

    const globalErrorMessage = document.getElementById("globalErrorMessage");
    globalErrorMessage.textContent =
      "Lūdzu, aizpildiet obligātos laukus pareizi.";
  }
});

function clearErrorMessages() {
    const allErrorMessages = document.querySelectorAll('.error-message');
    allErrorMessages.forEach(message => {
        message.textContent = '';
    });
    document.getElementById('globalErrorMessage').textContent = '';
}


function isValidEmail(email) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}


function isValidPhoneNumber(phone) {
    const phonePattern = /^\d+$/;
    return phonePattern.test(phone);
}


function isValidName(name) {
    const namePattern = /^[^\d]+$/;
    return namePattern.test(name);
}
