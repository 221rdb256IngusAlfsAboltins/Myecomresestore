window.addEventListener("scroll", function () {
  const navbar = document.getElementById("sidebar");

  if (window.scrollY > 233 && window.scrollY < 1100) {
    navbar.style.position = "fixed";
    navbar.style.top = `${233 - 80}px`;
  } else if (window.scrollY > 1000) {
    navbar.style.position = "absolute";
    navbar.style.top = "1250px";
  } else {
    navbar.style.position = "absolute";
    navbar.style.top = "390px";
  }
});
