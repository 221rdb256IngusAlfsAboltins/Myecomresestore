class Product {
  constructor(id, title, pictureUrl, price) {
    this.id = id;
    this.title = title;
    this.pictureUrl = pictureUrl;
    this.price = price;
  }
}

const higenaProductsList = [
  new Product(1, "STIN SONIC elektriskā zobubirste", "images/15.png", 6.99),
  new Product(2, "SENI autiņbikses", "images/16.png", 14.99),
  new Product(3, "ACNE CARE DEFENSE ziepes", "images/14.png", 16.39),
  new Product(4, "Higēna 4", "images/d3.png", 12.99),
  new Product(5, "Higēna 5", "images/d3.png", 14.19),
  new Product(6, "Higēna 6", "images/d3.png", 12.39),
];
const vitaminiProductsList = [
  new Product(7, "NOW omega-3 zivju eļļa", "images/3.png", 12.09),
  new Product(8, "NOW Ocu atbalsts muskuļiem", "images/4.png", 16.34),
  new Product(9, "NOW SAMe 400mg", "images/5.png", 28.33),
  new Product(10, "NOW 5-hto 100mg", "images/6.png", 20.31),
  new Product(11, "vitamini5", "images/d1.png", 9.99),
  new Product(12, "vitamini6", "images/d1.png", 8.29),
  new Product(13, "vitamini7", "images/d1.png", 4.39),
  new Product(14, "vitamini8", "images/d1.png", 1.99),
  new Product(15, "vitamini9", "images/d1.png", 2.99),
];

const citiProductsList = [
  new Product(16, "SENI autiņbikses", "images/16.png", 9.39),
  new Product(17, "GOLVE locītavas saites", "images/17.png", 22.09),
  new Product(18, "VERSAN uzturabagātinātājs locītavām", "images/18.png", 31.30),
  new Product(19, "FLEXISEQ smēre locītavām", "images/19.png", 10.94),
  new Product(20, "citiprodukti6", "images/d5.png", 30.99),
  new Product(21, "citiprodukti7", "images/d5.png", 14.99),
  new Product(22, "citiprodukti8", "images/d5.png", 10.39),
  new Product(23, "citiprodukti9", "images/d5.png", 11.29),

];
const veselibaProductsList= [
  new Product(23, "ACTOIL Termometrs dzīvsusdraba", "images/11.png", 12.19),
  new Product(25, "CLEARBLU grūtniecības tests", "images/12.png", 1.11),
  new Product(26, "BRONTEX 30mg tabletes", "images/13.png", 2.29),
  new Product(27, "veselība26", "images/d2.png", 11.99),
  new Product(28, "veselība27", "images/d2.png", 10.39),
  new Product(29, "veselība28", "images/d2.png", 9.99),
  new Product(30, "veselība29", "images/d2.png", 7.99),
  new Product(31, "veselība30", "images/d2.png", 6.99),
];

const skaistumsProductsList = [
  new Product(32, "CERA VE mitrinošais krēms", "images/7.png", 13.31),
  new Product(33, "BIODERMA Atoderm krēms", "images/9.png", 9.46),
  new Product(34, "MIKINISAL blaugznu šampūns", "images/8.png", 19.01),
  new Product(35, "CATAPHIL roku losjons", "images/10.png", 4.33),
  new Product(36, "skaistums1", "images/d4.png", 19.99),
  new Product(37, "skaistums2", "images/d4.png", 29.99),
  new Product(38, "skaistums3", "images/d4.png", 10.99),
  new Product(39, "skaistums4", "images/d4.png", 19.99),
  new Product(40, "skaistums5", "images/d4.png", 29.99),
  new Product(41, "skaistums6", "images/d4.png", 29.99),
  new Product(42, "skaistums7", "images/d4.png", 10.99),
  new Product(43, "skaistums8", "images/d4.png", 19.99),
  new Product(44, "skaistums9", "images/d4.png", 29.99),
  new Product(45, "skaistums10", "images/d4.png", 29.99),
  new Product(46, "skaistums11", "images/d4.png", 10.99),
  new Product(47, "skaistums12", "images/d4.png", 14.99),
  new Product(48, "skaistums13", "images/d4.png", 29.99),
  new Product(49, "skaistums14", "images/d4.png", 29.99),
  new Product(50, "skaistums15", "images/d4.png", 20.99),
  new Product(51, "skaistums16", "images/d4.png", 13.99),
  new Product(52, "skaistums17", "images/d4.png", 24.99),
  new Product(53, "skaistums18", "images/d4.png", 23.99),
  new Product(54, "skaistums23", "images/d4.png", 10.99),
  new Product(55, "skaistums25", "images/d4.png", 1.99),
  new Product(56, "skaistums26", "images/d4.png", 29.99),
  new Product(57, "skaistums27", "images/d4.png", 29.99),
  new Product(59, "skaistums28", "images/d4.png", 14.99),
  new Product(60, "skaistums29", "images/d4.png", 19.99),
  new Product(61, "skaistums30", "images/d4.png", 29.99),
  new Product(62, "skaistums31", "images/d4.png", 29.99),
  new Product(63, "skaistums32", "images/d4.png", 10.99),
  new Product(64, "skaistums33", "images/d4.png", 30.99),
  new Product(65, "skaistums33", "images/d4.png", 19.99),
  new Product(66, "skaistums34", "images/d4.png", 29.39),
  new Product(67, "skaistums35", "images/d4.png", 40.99),
  new Product(68, "skaistums36", "images/d4.png", 19.99),
  new Product(69, "skaistums37", "images/d4.png", 29.99),
  new Product(70, "skaistums38", "images/d4.png", 10.49),
  new Product(71, "skaistums39", "images/d4.png", 19.99),
  new Product(72, "skaistums40", "images/d4.png", 29.99),
  new Product(73, "skaistums41", "images/d4.png", 29.99),
  new Product(74, "skaistums42", "images/d4.png", 10.39),
  new Product(75, "skaistums43", "images/d4.png", 19.99),
  new Product(76, "skaistums44", "images/d4.png", 59.99),
];

const categoryMap = new Map([
  ["skaistums", ["Skaistums", skaistumsProductsList]],
  ["higena", ["Higēna", higenaProductsList]],
  ["vitamini", ["Vitamīni", vitaminiProductsList]],
  ["veseliba", ["Veselība", veselibaProductsList]],
  ["citi", ["Citi produkti", citiProductsList]],
]);

function renderProductDescription(item_id){

  console.log("renderproductsdecriptio", item_id);
}


console.log(categoryMap.get("skaistums"));

function renderProductsPageNumbers(productList) {
  const container = document.getElementById("product-container");
  


  const productsPerPage = 20;
  const pagesTotal = Math.ceil(productList.length / productsPerPage);

 
  const pageList = document.createElement("ul");
  pageList.classList.add("pageList");
  pageList.style.listStyleType = "none";
  pageList.style.padding = "0";


  for (let i = 1; i <= pagesTotal; i++) {
    const pageNumberItem = document.createElement("li");
    pageNumberItem.style.display = "inline";

    const pageButton = document.createElement("button");
    pageButton.textContent = i; 

  
    pageButton.addEventListener("click", function () {
      const startIndex = (i - 1) * productsPerPage;
      const endIndex = startIndex + (productsPerPage-1);
      console.log(startIndex,endIndex);
      renderProducts(productList, startIndex, endIndex);
      
    });

    pageNumberItem.appendChild(pageButton); 
    pageList.appendChild(pageNumberItem); 
  }

  container.appendChild(pageList); 
}



function renderProducts(productList, startIndex, endIndex) {
 
  
  const oldTable = document.getElementById("product-table-container");
oldTable.innerHTML ="";

  
  if (endIndex > productList.length) {
    endIndex = productList.length - 1;
     
  }
 
  const remainder = (endIndex + 1) % 5;
  if (remainder !== 0) {
    endIndex = endIndex + (5 - remainder);
    emptyCells = true;
    
  }
  const container = document.getElementById("product-table-container");

  const table = document.createElement("table");
  table.classList.add("product-table");

  let row ;
console.log(startIndex, endIndex);
  for (let index = startIndex,  i =0; index <= endIndex; index++, i++) {
   
     
    if (i % 5 === 0) {
      row = document.createElement("tr");
      
      table.appendChild(row);
    }
   
    const cell = document.createElement("td");
    cell.classList.add("product-cell");
    row.appendChild(cell);

    if (index <= productList.length - 1) {
      
      const product = productList[index];
      const contentContainer = document.createElement("div");
      contentContainer.classList.add("product-content");

      const imageContainer = document.createElement("div");
      imageContainer.classList.add("product-image-container");
      const link = document.createElement("a");
      link.href = `product-single.html?id=${product.id}`
      const picture = document.createElement("img");

      link.appendChild(picture);
      picture.src = product.pictureUrl;

      imageContainer.appendChild(link);

      const title = document.createElement("p");
      title.textContent = product.title;
      title.setAttribute("id", "product-content-title");

      const price = document.createElement("p");
      price.textContent = `$${product.price.toFixed(2)}`;

      contentContainer.appendChild(imageContainer);
      contentContainer.appendChild(title);
      contentContainer.appendChild(price);

      cell.appendChild(contentContainer);
    }
  }

  container.appendChild(table);

}





const navbar = document.getElementById("navbar-horizontals");
window.addEventListener("scroll", function () {
 
  if (window.scrollY > 40) {
    navbar.style.backgroundColor = "rgba(0, 0, 0, 0.93"; 
  } else {
    navbar.style.backgroundColor = "transparent"; 
  }
});

function getUrlParameter(name) {
  url = window.location.href;

  var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)");
  var results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return "";
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}




function decreaseQuantity() {
  const quantityInput = document.getElementById("quantity");
  let currentQuantity = parseInt(quantityInput.value);

  if (currentQuantity > 1) {
    currentQuantity--;
    quantityInput.value = currentQuantity;
  }
}


function increaseQuantity() {
  const quantityInput = document.getElementById("quantity");
  let currentQuantity = parseInt(quantityInput.value);

  if (currentQuantity < 10) {

    currentQuantity++;
    quantityInput.value = currentQuantity;
  }
}

function showDescription(sectionIndex) {
  const carouselContent = document.querySelector(".description-carousel");
  const sectionWidth = document.querySelector(".description-cell-text" ).offsetWidth;


  const translateX = -(sectionIndex - 1) * sectionWidth;

  carouselContent.style.transform = `translateX(${translateX}px)`;
}





function renderProductBascket() {
  const productBascket = JSON.parse(localStorage.getItem("bascket"));
  const productTableBody = document.getElementById("bascket-table-data");


  function updateSingleTotalPrice(event) {
    const quantity = parseInt(event.target.value);
    const price = parseFloat(event.target.dataset.price);
    const id = parseInt(event.target.dataset.id);

    updateBascketQuantity(id, quantity);

    const totalCell = event.target.parentElement.nextElementSibling;

    if (quantity === 0) {
  
      deletepRoductBascket(id);
      const row = event.target.closest("tr");
      row.remove();
    } else {
      
      const total = quantity * price;
      totalCell.innerHTML = `${total.toFixed(2)}&euro;`;
      updateTotalPrice();

    }
  }
  
  function updateTotalPrice(){
    const singleTotal = document.querySelectorAll( ".single-total-price" );
    const bezPVN = document.getElementById("bez-pvn");
    const pvn = document.getElementById("pvn");
    const total = document.getElementById("total");
    const kopsumma = document.getElementById("kopsumma")
    let sum = 0;
    singleTotal.forEach(function(price) {
      const textContent = price.textContent.trim().replace("€", "");
      const value = parseFloat(textContent); 
      sum += value;

    });
    const calcBezPVN = (sum / 1.21).toFixed(2);
    total.innerHTML = `${sum.toFixed(2)}&euro;`;
    bezPVN.innerHTML = `${calcBezPVN}&euro;`;
    pvn.innerHTML = `${(sum - calcBezPVN).toFixed(2)}&euro;`;
    kopsumma.innerHTML = total.innerHTML;
  }

  function incrementQuantity(event) {
    const input = event.target.previousElementSibling;
    input.value = parseInt(input.value) + 1;
    input.dispatchEvent(new Event("input")); 
  }

  
  function decrementQuantity(event) {
    const input = event.target.nextElementSibling;
    if (parseInt(input.value) > 0) {
      input.value = parseInt(input.value) - 1;
      input.dispatchEvent(new Event("input")); 
    }
  }

 
  productBascket.forEach((product) => {
    const row = document.createElement("tr");

    const pictureCell = document.createElement("td");
    const pictureImg = document.createElement("img");
    pictureImg.src = product.pictureUrl;
    pictureImg.alt = product.name;
    pictureCell.appendChild(pictureImg);
    row.appendChild(pictureCell);

  
    const nameCell = document.createElement("td");
    nameCell.textContent = product.name;
    row.appendChild(nameCell);

   
    const priceCell = document.createElement("td");
    priceCell.innerHTML = `${product.price.toFixed(2)}&euro;`;
    row.appendChild(priceCell);


    const quantityCell = document.createElement("td");
    quantityCell.classList.add("quantity-input-container");
    
    const quantityInput = document.createElement("input");
    quantityInput.type = "number";
    quantityInput.value = product.quantity;
    quantityInput.min = 0;
    quantityInput.dataset.price = product.price;
    quantityInput.dataset.id = product.id;

    const decrementButton = document.createElement("button");
    decrementButton.textContent = "-";
    decrementButton.addEventListener("click", decrementQuantity);
    quantityCell.appendChild(decrementButton);

    quantityInput.addEventListener("input", updateSingleTotalPrice);
    quantityCell.appendChild(quantityInput);

    const incrementButton = document.createElement("button");
    incrementButton.textContent = "+";
    incrementButton.addEventListener("click", incrementQuantity);
    quantityCell.appendChild(incrementButton);

  

    row.appendChild(quantityCell);

    const totalCell = document.createElement("td");
    const totalPrice = product.price * product.quantity;
    totalCell.classList.add("single-total-price")
    totalCell.innerHTML = `${totalPrice.toFixed(2)}&euro;`;
    row.appendChild(totalCell);

    productTableBody.appendChild(row);
  });

  updateTotalPrice();

}
if (!localStorage.hasOwnProperty("bascket")) {
  initializeLocalStorage();
  console.log("testinttt");
}

function initializeLocalStorage(){

 

  localStorage.setItem("bascket", "[]");
  localStorage.setItem("currentUser","");

}
function updateBascketQuantity(id, quantity){
    const productBascket = JSON.parse(localStorage.getItem("bascket"));
    productBascket.forEach(function(product){
      if(product.id == id){
        product.quantity = quantity;
      }
    });
    const productBascketJSON = JSON.stringify(productBascket);


    localStorage.setItem("bascket", productBascketJSON);
}
function deletepRoductBascket(id){
    const productBascket = JSON.parse(localStorage.getItem("bascket"));
    productBascket.forEach(function(product,index){
      if(product.id == id){
        productBascket.splice(index, 1);
      }
    });
    const productBascketJSON = JSON.stringify(productBascket);

    localStorage.setItem("bascket", productBascketJSON);
}
function addToBascket(event){
  const quantityValue = document.getElementById("quantity");
  const product = JSON.parse(event.target.dataset.product);
  product["quantity"] = parseInt(quantityValue.value); 
  console.log(product);

  const productBascket = JSON.parse(localStorage.getItem("bascket"));
  productBascket.push(product);
  const productBascketJSON = JSON.stringify(productBascket);

  localStorage.setItem("bascket", productBascketJSON);
}



let currentSlideIndex = 0;

function showSlide(slideIndex) {
  const bannerSlides = document.querySelector(".banner-slides");
  const slideWidth = bannerSlides.clientWidth;

  const translateX = -slideIndex * slideWidth;

  bannerSlides.style.transform = `translateX(${translateX}px)`;

  currentSlideIndex = slideIndex;
}
setInterval(() => {
    
    const nextSlideIndex = (currentSlideIndex + 1) % 4; 
    showSlide(nextSlideIndex);
}, 15000); 


function findProductById(id) {
  let result = null;

  categoryMap.forEach(([categoryName, productsList]) => {
    const foundProduct = productsList.find((product) => product.id === id);

    if (foundProduct) {
      result = [categoryName, foundProduct]; 
    }
  });

  return result; 
}
function renderProdcutDescription(product){
  console.log("good");
  const price = document.getElementById("single-product-price");
  price.innerHTML = `${product.price}&euro;`;
  const title = document.getElementById("details-cell-prodcut-name");
  title.innerHTML = `${product.title}`
  const imageSrc = document.getElementById("image-src");
  imageSrc.src = `${product.pictureUrl}`
  const button = document.getElementById("add-bascket-btn");
  const productJSON = JSON.stringify(product);
  button.dataset.product = productJSON;
  button.addEventListener("click",addToBascket);
  

}
window.addEventListener("scroll", function () {
  const navbar = document.getElementById("sidebar");

  if (window.scrollY > 233 && window.scrollY < 1100) {
    navbar.style.position = "fixed";
    navbar.style.top = `${233 - 80}px`;
  } else if (window.scrollY > 1000) {
    navbar.style.position = "absolute";
    navbar.style.top = "1250px";
  } else {
    navbar.style.position = "absolute";
    navbar.style.top = "390px";
  }
});

document.addEventListener("DOMContentLoaded", () => {
  const pathName = window.location.pathname;
  if (
    pathName === "/product-table.html" 
  ) {
    var category = getUrlParameter("category");
    const productsList = categoryMap.get(category)[1];
    const categoryText = categoryMap.get(category)[0];
    const routeText = `Mājas &rarr;${categoryText}`;

    const route = document.getElementById("container-main-header-route");
    const title = document.getElementById("container-main-header-title");
    const productAmount = document.getElementById(
      "container-main-header-amount"
    );

    route.innerHTML = routeText;
    title.innerHTML = categoryText;
    productAmount.innerHTML = `${productsList.length}`;
    var productsInPage = 20;

    renderProducts(productsList, 0, productsInPage - 1);
    renderProductsPageNumbers(productsList);
    
  } else if (pathName === "/product-single.html") {
        console.log("test");
        let  id = getUrlParameter("id");
        const product = findProductById(parseInt(id));
        const productText = product[1].title;

        const categoryText = product[0];

        const routeText = `Mājas &rarr;${categoryText}&rarr;${productText}`;

        const route = document.getElementById("container-main-header-route");
        const title = document.getElementById("container-main-header-title");
         route.innerHTML = routeText;
         title.innerHTML = categoryText;
        renderProdcutDescription(product[1]);

        
  } else if (pathName === "/bascket.html") {
   

    renderProductBascket();
  }

});


